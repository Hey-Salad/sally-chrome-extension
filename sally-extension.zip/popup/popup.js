/**
 * Sally by HeySalad® - Popup Script
 */

// DOM Elements
const authSection = document.getElementById('auth-section');
const mainSection = document.getElementById('main-section');
const loginForm = document.getElementById('login-form');
const loginBtn = document.getElementById('login-btn');
const loginMessage = document.getElementById('login-message');
const emailStep = document.getElementById('email-step');
const tokenStep = document.getElementById('token-step');
const verifyBtn = document.getElementById('verify-btn');
const backBtn = document.getElementById('back-btn');
const userEmail = document.getElementById('user-email');
const logoutBtn = document.getElementById('logout-btn');
const taskForm = document.getElementById('task-form');
const taskStatus = document.getElementById('task-status');
const taskComplete = document.getElementById('task-complete');
const storeSelect = document.getElementById('store-select');
const itemsInput = document.getElementById('items-input');
const postcodeInput = document.getElementById('postcode-input');
const startBtn = document.getElementById('start-btn');
const stopBtn = document.getElementById('stop-btn');
const taskStore = document.getElementById('task-store');
const progressFill = document.getElementById('progress-fill');
const progressText = document.getElementById('progress-text');
const itemsList = document.getElementById('items-list');
const completeSummary = document.getElementById('complete-summary');
const viewCartBtn = document.getElementById('view-cart-btn');
const newTaskBtn = document.getElementById('new-task-btn');

let currentUser = null;
let currentTask = null;
let timerInterval = null;

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  await checkAuthStatus();
  await checkTaskStatus();
  await loadStats();
  await loadSavedLists();
  setupEventListeners();
});

// Load and display user stats
async function loadStats() {
  try {
    const data = await chrome.storage.local.get(['sallyStats']);
    const stats = data.sallyStats || { totalItems: 0, totalSessions: 0, totalSpent: 0 };
    
    document.getElementById('stat-items').textContent = stats.totalItems || 0;
    document.getElementById('stat-sessions').textContent = stats.totalSessions || 0;
    
    // Estimate time saved: ~30 seconds per item (searching, comparing, adding)
    const minutesSaved = Math.round((stats.totalItems || 0) * 0.5);
    document.getElementById('stat-time').textContent = minutesSaved > 0 ? `${minutesSaved} min` : '0 min';
  } catch (e) {
    console.error('Failed to load stats:', e);
  }
}

// Update stats after shopping session
async function updateStats(itemsAdded) {
  try {
    const data = await chrome.storage.local.get(['sallyStats']);
    const stats = data.sallyStats || { totalItems: 0, totalSessions: 0, totalSpent: 0 };
    
    stats.totalItems += itemsAdded;
    stats.totalSessions += 1;
    
    await chrome.storage.local.set({ sallyStats: stats });
    await loadStats();
  } catch (e) {
    console.error('Failed to update stats:', e);
  }
}

// Timer functions
function startTimer() {
  if (timerInterval) clearInterval(timerInterval);
  
  const timerEl = document.getElementById('shopping-timer');
  if (!timerEl) return;
  
  // Get start time from task or now
  const startTime = currentTask?.startedAt ? new Date(currentTask.startedAt).getTime() : Date.now();
  
  const updateTimer = () => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    const mins = Math.floor(elapsed / 60);
    const secs = elapsed % 60;
    timerEl.textContent = `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  updateTimer();
  timerInterval = setInterval(updateTimer, 1000);
}

function stopTimer() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

function formatDuration(startTime, endTime) {
  const start = new Date(startTime).getTime();
  const end = endTime ? new Date(endTime).getTime() : Date.now();
  const elapsed = Math.floor((end - start) / 1000);
  const mins = Math.floor(elapsed / 60);
  const secs = elapsed % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Load saved shopping lists
async function loadSavedLists() {
  try {
    const data = await chrome.storage.local.get(['taskHistory']);
    const history = data.taskHistory || [];
    const container = document.getElementById('saved-lists-container');
    
    if (!container) return;
    
    // Filter to only completed tasks
    const completedTasks = history.filter(t => t.status === 'complete').slice(0, 5);
    
    if (completedTasks.length === 0) {
      container.innerHTML = '<p class="empty-state">No saved lists yet</p>';
      return;
    }
    
    const storeNames = {
      tesco: 'Tesco',
      sainsburys: "Sainsbury's",
      asda: 'ASDA',
      ocado: 'Ocado',
      waitrose: 'Waitrose'
    };
    
    container.innerHTML = completedTasks.map((task, index) => {
      const date = new Date(task.completedAt || task.startedAt);
      const dateStr = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
      const itemCount = task.items?.length || 0;
      const addedCount = task.itemsAdded || task.items?.filter(i => i.status === 'added').length || 0;
      const duration = task.startedAt && task.completedAt ? formatDuration(task.startedAt, task.completedAt) : '';
      
      return `
        <div class="saved-list-item" data-index="${index}">
          <div class="saved-list-info">
            <div class="saved-list-store">${storeNames[task.store] || task.store}</div>
            <div class="saved-list-meta">${dateStr}${duration ? ` • ${duration}` : ''}</div>
          </div>
          <span class="saved-list-count">${addedCount}/${itemCount}</span>
        </div>
      `;
    }).join('');
    
    // Add click handlers to reuse lists
    container.querySelectorAll('.saved-list-item').forEach(item => {
      item.addEventListener('click', () => {
        const index = parseInt(item.dataset.index);
        const task = completedTasks[index];
        if (task && task.items) {
          const itemsText = task.items.map(i => 
            i.quantity > 1 ? `${i.quantity}x ${i.name}` : i.name
          ).join('\n');
          itemsInput.value = itemsText;
          storeSelect.value = task.store || '';
          showTaskForm();
        }
      });
    });
  } catch (e) {
    console.error('Failed to load saved lists:', e);
  }
}

// Clear history
async function clearHistory() {
  if (!confirm('Clear all saved shopping lists?')) return;
  await chrome.storage.local.set({ taskHistory: [] });
  await loadSavedLists();
}

// Listen for updates from background
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'TASK_UPDATED') {
    updateTaskUI(message.task);
  } else if (message.type === 'SHOPPING_COMPLETE') {
    showTaskComplete(message.task);
  } else if (message.type === 'AUTH_SUCCESS') {
    currentUser = message.user;
    showMainSection();
  }
});

async function checkAuthStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'AUTH_CHECK' });
    if (response.isAuthenticated) {
      currentUser = response.user;
      showMainSection();
    } else {
      showAuthSection();
    }
  } catch (error) {
    console.error('Auth check error:', error);
    showAuthSection();
  }
}

async function checkTaskStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_TASK_STATUS' });
    if (response.task) {
      currentTask = response.task;
      if (currentTask.status === 'complete') {
        showTaskComplete(currentTask);
      } else if (currentTask.status !== 'stopped') {
        showTaskStatus();
        updateTaskUI(currentTask);
      }
    }
  } catch (error) {
    console.error('Task status error:', error);
  }
}

function setupEventListeners() {
  loginForm.addEventListener('submit', handleLogin);
  verifyBtn.addEventListener('click', handleVerifyToken);
  backBtn.addEventListener('click', () => {
    emailStep.classList.remove('hidden');
    tokenStep.classList.add('hidden');
    hideMessage();
  });
  logoutBtn.addEventListener('click', handleLogout);
  startBtn.addEventListener('click', handleStartShopping);
  stopBtn.addEventListener('click', handleStopShopping);
  viewCartBtn.addEventListener('click', handleViewCart);
  newTaskBtn.addEventListener('click', handleNewTask);
  
  // Clear history button
  const clearHistoryBtn = document.getElementById('clear-history-btn');
  if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener('click', clearHistory);
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('email').value.trim();
  
  if (!email) {
    showMessage('Please enter your email', 'error');
    return;
  }
  
  loginBtn.disabled = true;
  loginBtn.innerHTML = '<span class="spinner"></span> Sending...';
  
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'AUTH_LOGIN',
      data: { email }
    });
    
    if (response.success) {
      // Show token step
      emailStep.classList.add('hidden');
      tokenStep.classList.remove('hidden');
      showMessage('Magic link sent! Check your email.', 'success');
    } else {
      showMessage(response.error || 'Failed to send magic link', 'error');
    }
  } catch (error) {
    showMessage('An error occurred. Please try again.', 'error');
  } finally {
    loginBtn.disabled = false;
    loginBtn.innerHTML = '<span>Send Magic Link</span>';
  }
}

async function handleVerifyToken() {
  const token = document.getElementById('token').value.trim();
  
  if (!token) {
    showMessage('Please paste your token', 'error');
    return;
  }
  
  verifyBtn.disabled = true;
  verifyBtn.innerHTML = '<span class="spinner"></span> Verifying...';
  
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'AUTH_CALLBACK',
      data: { token }
    });
    
    if (response.success) {
      currentUser = response.user;
      showMainSection();
    } else {
      showMessage(response.error || 'Invalid token', 'error');
    }
  } catch (error) {
    showMessage('Verification failed. Please try again.', 'error');
  } finally {
    verifyBtn.disabled = false;
    verifyBtn.innerHTML = '<span>Sign In</span>';
  }
}

async function handleLogout() {
  try {
    await chrome.runtime.sendMessage({ type: 'AUTH_LOGOUT' });
    currentUser = null;
    currentTask = null;
    showAuthSection();
  } catch (error) {
    console.error('Logout error:', error);
  }
}

async function handleStartShopping() {
  const store = storeSelect.value;
  const itemsText = itemsInput.value.trim();
  const postcode = postcodeInput.value.trim();
  
  // Store is now optional - we'll detect from current tab
  if (!itemsText) {
    alert('Please enter at least one item');
    return;
  }
  
  const items = parseItems(itemsText);
  if (items.length === 0) {
    alert('Please enter valid items');
    return;
  }
  
  startBtn.disabled = true;
  startBtn.innerHTML = '<span class="spinner"></span> Starting...';
  
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'START_SHOPPING',
      data: { store: store || undefined, items, deliveryPostcode: postcode || undefined }
    });
    
    if (response.success) {
      currentTask = {
        id: response.taskId,
        store: response.store,
        items: items.map(i => ({ ...i, status: 'pending' })),
        status: 'shopping',
        mode: response.mode
      };
      showTaskStatus();
      updateTaskUI(currentTask);
    } else {
      // Show helpful error message
      if (response.error && response.error.includes('supermarket website')) {
        alert('🛒 Please navigate to a supermarket website first!\n\nSupported stores:\n• Tesco\n• Sainsbury\'s\n• ASDA\n• Ocado\n• Waitrose');
      } else {
        alert(response.error || 'Failed to start shopping');
      }
    }
  } catch (error) {
    console.error('Start shopping error:', error);
    alert('An error occurred. Please try again.');
  } finally {
    startBtn.disabled = false;
    startBtn.innerHTML = '<span>🛒 Let Sally Shop!</span>';
  }
}

async function handleStopShopping() {
  if (!confirm('Stop shopping?')) return;
  
  try {
    await chrome.runtime.sendMessage({ type: 'STOP_SHOPPING' });
    currentTask = null;
    showTaskForm();
  } catch (error) {
    console.error('Stop error:', error);
  }
}

function handleViewCart() {
  if (currentTask && currentTask.store) {
    const cartUrls = {
      tesco: 'https://www.tesco.com/groceries/en-GB/trolley',
      sainsburys: 'https://www.sainsburys.co.uk/gol-ui/trolley',
      asda: 'https://groceries.asda.com/trolley',
      ocado: 'https://www.ocado.com/webshop/getBasket.do',
      waitrose: 'https://www.waitrose.com/ecom/shop/trolley'
    };
    const url = cartUrls[currentTask.store];
    if (url) chrome.tabs.create({ url });
  }
}

function handleNewTask() {
  currentTask = null;
  itemsInput.value = '';
  showTaskForm();
}

function parseItems(text) {
  const lines = text.split('\n').filter(line => line.trim());
  const items = [];
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    
    let name = trimmed;
    let quantity = 1;
    
    // Try "2x Item" format
    const prefixMatch = trimmed.match(/^(\d+)\s*x\s+(.+)$/i);
    if (prefixMatch) {
      quantity = parseInt(prefixMatch[1], 10);
      name = prefixMatch[2].trim();
    } else {
      // Try "Item x2" format
      const suffixMatch = trimmed.match(/^(.+?)\s*x\s*(\d+)$/i);
      if (suffixMatch) {
        name = suffixMatch[1].trim();
        quantity = parseInt(suffixMatch[2], 10);
      } else {
        // Try "Item (2)" format
        const parenMatch = trimmed.match(/^(.+?)\s*\((\d+)\)$/);
        if (parenMatch) {
          name = parenMatch[1].trim();
          quantity = parseInt(parenMatch[2], 10);
        }
      }
    }
    
    if (name && quantity > 0) {
      items.push({ name, quantity });
    }
  }
  
  return items;
}

function showAuthSection() {
  authSection.classList.remove('hidden');
  mainSection.classList.add('hidden');
  emailStep.classList.remove('hidden');
  tokenStep.classList.add('hidden');
}

function showMainSection() {
  authSection.classList.add('hidden');
  mainSection.classList.remove('hidden');
  if (currentUser) {
    userEmail.textContent = currentUser.email || currentUser.phone || 'User';
  }
}

function showTaskForm() {
  taskForm.classList.remove('hidden');
  taskStatus.classList.add('hidden');
  taskComplete.classList.add('hidden');
  
  // Show saved lists when returning to form
  const savedLists = document.getElementById('saved-lists');
  if (savedLists) savedLists.classList.remove('hidden');
  
  // Reload saved lists in case they changed
  loadSavedLists();
}

function showTaskStatus() {
  taskForm.classList.add('hidden');
  taskStatus.classList.remove('hidden');
  taskComplete.classList.add('hidden');
  
  // Hide saved lists during shopping
  const savedLists = document.getElementById('saved-lists');
  if (savedLists) savedLists.classList.add('hidden');
  
  // Start the timer
  startTimer();
}

function showTaskComplete(task) {
  // Handle case where task is undefined - get from storage
  if (!task) {
    chrome.storage.local.get(['currentTask'], (data) => {
      if (data.currentTask) {
        showTaskComplete(data.currentTask);
      }
    });
    return;
  }
  
  // Stop the timer
  stopTimer();
  
  taskForm.classList.add('hidden');
  taskStatus.classList.add('hidden');
  taskComplete.classList.remove('hidden');
  
  // Show saved lists again
  const savedLists = document.getElementById('saved-lists');
  if (savedLists) savedLists.classList.remove('hidden');
  
  // Calculate from items array if itemsAdded not set
  const added = task.itemsAdded || task.items?.filter(i => i.status === 'added').length || 0;
  const failed = task.itemsFailed || task.items?.filter(i => i.status === 'failed').length || 0;
  const total = task.items?.length || 0;
  
  const storeNames = {
    tesco: 'Tesco',
    sainsburys: "Sainsbury's",
    asda: 'ASDA',
    ocado: 'Ocado',
    waitrose: 'Waitrose'
  };
  const storeName = storeNames[task.store] || task.store || 'your';
  
  completeSummary.textContent = `Added ${added} of ${total} items to your ${storeName} cart.`;
  if (failed > 0) {
    completeSummary.textContent += ` ${failed} items couldn't be found.`;
  }
  
  // Show duration
  const completeTime = document.getElementById('complete-time');
  if (completeTime && task.startedAt) {
    const duration = formatDuration(task.startedAt, task.completedAt);
    completeTime.textContent = `⏱ Completed in ${duration}`;
  }
  
  // Update stats if items were added (only once per task)
  if (added > 0 && !task.statsUpdated) {
    task.statsUpdated = true;
    chrome.storage.local.set({ currentTask: task });
    updateStats(added);
  }
  
  // Reload saved lists to show the new one
  loadSavedLists();
}

function updateTaskUI(task) {
  if (!task) return;
  currentTask = task;
  
  const storeNames = {
    tesco: 'Tesco',
    sainsburys: "Sainsbury's",
    asda: 'ASDA',
    ocado: 'Ocado',
    waitrose: 'Waitrose'
  };
  
  // Show status-specific messages
  let statusText = storeNames[task.store] || task.store;
  if (task.status === 'starting') {
    statusText = `Connecting to ${statusText}...`;
  } else if (task.status === 'shopping') {
    statusText = `🤖 Sally is shopping at ${statusText}`;
  } else if (task.status === 'manual' || task.status === 'fallback') {
    statusText = `Manual mode - ${statusText}`;
  } else if (task.status === 'error') {
    statusText = `Error - ${task.error || 'Unknown error'}`;
  }
  taskStore.textContent = statusText;
  
  const total = task.items?.length || 0;
  const completed = (task.itemsAdded || 0) + (task.itemsFailed || 0);
  const percent = total > 0 ? (completed / total) * 100 : 0;
  
  // Show indeterminate progress while shopping
  if (task.status === 'starting' || task.status === 'shopping') {
    progressFill.style.width = '100%';
    progressFill.style.animation = 'pulse 1.5s ease-in-out infinite';
    progressText.textContent = task.status === 'starting' 
      ? 'Initializing AI browser...' 
      : 'Sally is adding items to your cart...';
  } else {
    progressFill.style.animation = 'none';
    progressFill.style.width = `${percent}%`;
    progressText.textContent = `${completed} of ${total} items`;
  }
  
  itemsList.innerHTML = '';
  if (task.items) {
    for (const item of task.items) {
      const row = document.createElement('div');
      row.className = 'item-row';
      
      const icon = item.status === 'added' ? '✓' : item.status === 'failed' ? '✗' : item.status === 'searching' ? '⏳' : '○';
      const price = item.price ? `£${item.price.toFixed(2)}` : '';
      
      row.innerHTML = `
        <span class="item-status ${item.status}">${icon}</span>
        <span class="item-name">${item.name} ${item.quantity > 1 ? `(×${item.quantity})` : ''}</span>
        <span class="item-price">${price}</span>
      `;
      
      itemsList.appendChild(row);
    }
  }
  
  // Handle fallback/manual mode
  if (task.status === 'manual' || task.status === 'fallback') {
    const fallbackMsg = document.createElement('div');
    fallbackMsg.className = 'fallback-message';
    fallbackMsg.innerHTML = `
      <p>⚠️ Automatic shopping unavailable.</p>
      <p>I've opened ${storeNames[task.store] || task.store} for you to shop manually.</p>
      ${task.fallbackReason ? `<p class="error-detail">${task.fallbackReason}</p>` : ''}
    `;
    itemsList.insertBefore(fallbackMsg, itemsList.firstChild);
  }
}

function showMessage(text, type) {
  loginMessage.textContent = text;
  loginMessage.className = `message ${type}`;
  loginMessage.classList.remove('hidden');
}

function hideMessage() {
  loginMessage.classList.add('hidden');
}
