/**
 * Sally by HeySalad® - Background Service Worker
 * 
 * Now uses the Shopping Agent's CUA (Computer Use Agent) API
 * for TRUE autonomous shopping via OpenAI's vision-based browser control.
 * 
 * Handles:
 * - OAuth authentication with oauth.heysalad.app
 * - Shopping task management via CUA API
 * - Real-time status updates
 */

const OAUTH_URL = 'https://oauth.heysalad.app';
const SHOPPING_AGENT_URL = 'https://shopping-agent.heysalad-o.workers.dev';

// Store URLs for manual fallback
const STORE_URLS = {
  tesco: 'https://www.tesco.com/groceries/',
  sainsburys: 'https://www.sainsburys.co.uk/gol-ui/',
  asda: 'https://groceries.asda.com/',
  ocado: 'https://www.ocado.com/',
  waitrose: 'https://www.waitrose.com/ecom/shop/'
};

const CART_URLS = {
  tesco: 'https://www.tesco.com/groceries/en-GB/trolley',
  sainsburys: 'https://www.sainsburys.co.uk/gol-ui/trolley',
  asda: 'https://groceries.asda.com/trolley',
  ocado: 'https://www.ocado.com/webshop/getBasket.do',
  waitrose: 'https://www.waitrose.com/ecom/shop/trolley'
};

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  console.log('[Sally] Extension installed');
  chrome.storage.local.set({ 
    isAuthenticated: false,
    currentTask: null,
    taskHistory: []
  });
});

// Listen for tab updates to re-inject content script after navigation
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // Only act when page is fully loaded
  if (changeInfo.status !== 'complete') return;
  
  // Check if we have an active task
  const data = await chrome.storage.local.get(['currentTask']);
  const task = data.currentTask;
  
  if (!task || task.status === 'complete' || task.status === 'stopped') return;
  
  // Check if this is a supermarket URL
  const url = tab.url || '';
  const isSupported = url.includes('tesco.com') || 
                      url.includes('sainsburys.co.uk') || 
                      url.includes('asda.com') || 
                      url.includes('ocado.com') || 
                      url.includes('waitrose.com');
  
  if (!isSupported) return;
  
  console.log('[Sally] Tab updated, re-injecting content script:', url);
  
  try {
    // Inject content script
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content-scripts/base.js']
    });
    
    // Also inject CSS
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ['content-scripts/overlay.css']
    });
    
    console.log('[Sally] Content script re-injected successfully');
  } catch (e) {
    console.log('[Sally] Could not inject content script:', e.message);
  }
});

// Listen for messages from popup and content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Sally] Message:', message.type, sender.tab ? `from tab ${sender.tab.id}` : 'from popup');
  
  handleMessage(message, sender).then(sendResponse);
  return true; // Keep channel open for async response
});

async function handleMessage(message, sender) {
  try {
    switch (message.type) {
      case 'AUTH_LOGIN':
        return await handleLogin(message.data);
      case 'AUTH_CALLBACK':
        return await handleAuthCallback(message.data?.token);
      case 'AUTH_LOGOUT':
        return await handleLogout();
      case 'AUTH_CHECK':
        return await checkAuth();
      case 'START_SHOPPING':
        return await startShopping(message.data);
      case 'STOP_SHOPPING':
        return await stopShopping();
      case 'GET_TASK_STATUS':
        return await getTaskStatus();
      case 'CHECK_CUA_STATUS':
        return await checkCUAStatus();
      // Content script progress messages
      case 'ITEM_ADDED':
        return await handleItemAdded(message.data);
      case 'ITEM_FAILED':
        return await handleItemFailed(message.data);
      case 'SHOPPING_COMPLETE':
        return await handleShoppingComplete();
      default:
        return { error: 'Unknown message type' };
    }
  } catch (error) {
    console.error('[Sally] Error:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Handle login - send magic link
 */
async function handleLogin(data) {
  const { email } = data;
  
  try {
    const response = await fetch(`${OAUTH_URL}/api/auth/send-magic-link`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        email,
        redirectUrl: `${OAUTH_URL}/login?source=sally`
      })
    });
    
    const result = await response.json();
    
    if (result.success) {
      return { success: true, message: 'Check your email for the magic link!' };
    } else {
      return { success: false, error: result.message || 'Failed to send magic link' };
    }
  } catch (error) {
    console.error('[Sally] Login error:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Handle OAuth callback with token
 */
async function handleAuthCallback(token) {
  if (!token) {
    return { success: false, error: 'No token provided' };
  }
  
  try {
    // Validate token with OAuth service
    const response = await fetch(`${OAUTH_URL}/api/auth/validate`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    
    const result = await response.json();
    
    if (result.valid) {
      await chrome.storage.local.set({ 
        isAuthenticated: true,
        authToken: token,
        user: result.user
      });
      
      return { success: true, user: result.user };
    } else {
      return { success: false, error: result.message || 'Invalid token' };
    }
  } catch (error) {
    console.error('[Sally] Auth callback error:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Handle logout
 */
async function handleLogout() {
  await chrome.storage.local.set({ 
    isAuthenticated: false,
    authToken: null,
    user: null,
    currentTask: null
  });
  return { success: true };
}

/**
 * Check authentication status
 */
async function checkAuth() {
  const data = await chrome.storage.local.get(['isAuthenticated', 'authToken', 'user']);
  
  if (data.isAuthenticated && data.authToken) {
    try {
      const response = await fetch(`${OAUTH_URL}/api/auth/validate`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${data.authToken}`
        }
      });
      
      const result = await response.json();
      
      if (result.valid) {
        return { isAuthenticated: true, user: result.user };
      }
    } catch (error) {
      console.error('[Sally] Token validation error:', error);
    }
    
    // Token invalid, clear auth
    await handleLogout();
  }
  
  return { isAuthenticated: false };
}

/**
 * Check CUA (Computer Use Agent) availability
 */
async function checkCUAStatus() {
  try {
    const response = await fetch(`${SHOPPING_AGENT_URL}/api/cua/status`);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('[Sally] CUA status check error:', error);
    return { 
      available: false, 
      error: error.message,
      message: 'Could not connect to Shopping Agent'
    };
  }
}

/**
 * Start a shopping task using LOCAL BROWSER CONTROL
 * 
 * Works in the CURRENT ACTIVE TAB - user should already be on a supermarket site.
 * The extension controls the browser directly:
 * 1. Uses the user's logged-in session
 * 2. No anti-bot detection (it's their real browser)
 * 3. Full DOM access for clicking buttons
 * 4. No new tabs - works in the current tab
 */
async function startShopping(data) {
  const { store, items, deliveryPostcode } = data;
  
  if (!items || items.length === 0) {
    return { success: false, error: 'Items are required' };
  }
  
  // Get the current active tab
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!activeTab) {
    return { success: false, error: 'No active tab found. Please open a supermarket website first.' };
  }
  
  // Detect which store we're on from the URL
  const detectedStore = detectStore(activeTab.url);
  const finalStore = store || detectedStore;
  
  if (!finalStore) {
    return { 
      success: false, 
      error: 'Please navigate to a supermarket website first (Tesco, Sainsbury\'s, ASDA, Ocado, or Waitrose).' 
    };
  }
  
  // Verify we're on the right store
  if (store && detectedStore && store !== detectedStore) {
    return { 
      success: false, 
      error: `You selected ${store} but you're on ${detectedStore}. Please navigate to ${store} or change your selection.` 
    };
  }
  
  const cartUrl = CART_URLS[finalStore];
  
  // Create task record
  const task = {
    id: crypto.randomUUID(),
    store: finalStore,
    items: items.map(item => ({ 
      name: item.name || item, 
      quantity: item.quantity || 1,
      status: 'pending' 
    })),
    deliveryPostcode,
    status: 'shopping',
    startedAt: new Date().toISOString(),
    itemsAdded: 0,
    itemsFailed: 0,
    mode: 'local',
    tabId: activeTab.id,
    cartUrl
  };
  
  await chrome.storage.local.set({ currentTask: task });
  
  console.log('[Sally] Starting LOCAL shopping in current tab for', finalStore, 'with', items.length, 'items');
  
  try {
    // Inject content script if needed
    try {
      await chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        files: ['content-scripts/base.js']
      });
    } catch (e) {
      console.log('[Sally] Content script may already be loaded:', e.message);
    }
    
    // Wait a bit for content script to initialize
    await sleep(500);
    
    // Send the shopping task to the content script
    try {
      const response = await chrome.tabs.sendMessage(activeTab.id, {
        type: 'START_SHOPPING_TASK',
        task: task
      });
      console.log('[Sally] Content script response:', response);
    } catch (e) {
      console.log('[Sally] Content script not responding, navigating to first search...');
      // Navigate to search for first item in the current tab
      const firstItem = task.items[0];
      const searchUrl = getSearchUrl(finalStore, firstItem.name);
      await chrome.tabs.update(activeTab.id, { url: searchUrl });
    }
    
    // Notify popup
    chrome.runtime.sendMessage({ type: 'TASK_UPDATED', task }).catch(() => {});
    
    return { 
      success: true, 
      taskId: task.id,
      store: finalStore,
      mode: 'local',
      message: `Shopping started! Adding ${items.length} items to your ${finalStore} cart...`
    };
    
  } catch (error) {
    console.error('[Sally] Local shopping error:', error);
    
    task.status = 'error';
    task.error = error.message;
    await chrome.storage.local.set({ currentTask: task });
    
    chrome.runtime.sendMessage({ type: 'TASK_UPDATED', task }).catch(() => {});
    
    return { 
      success: false, 
      taskId: task.id,
      error: error.message 
    };
  }
}

/**
 * Detect which store the user is on based on URL
 */
function detectStore(url) {
  if (!url) return null;
  
  if (url.includes('tesco.com')) return 'tesco';
  if (url.includes('sainsburys.co.uk')) return 'sainsburys';
  if (url.includes('asda.com')) return 'asda';
  if (url.includes('ocado.com')) return 'ocado';
  if (url.includes('waitrose.com')) return 'waitrose';
  
  return null;
}

/**
 * Get search URL for a store
 */
function getSearchUrl(store, query) {
  const encodedQuery = encodeURIComponent(query);
  switch (store) {
    case 'tesco':
      return `https://www.tesco.com/groceries/en-GB/search?query=${encodedQuery}`;
    case 'sainsburys':
      return `https://www.sainsburys.co.uk/gol-ui/SearchResults/${encodedQuery}`;
    case 'asda':
      return `https://groceries.asda.com/search/${encodedQuery}`;
    case 'ocado':
      return `https://www.ocado.com/search?q=${encodedQuery}`;
    case 'waitrose':
      return `https://www.waitrose.com/ecom/shop/search?searchTerm=${encodedQuery}`;
    default:
      return STORE_URLS[store];
  }
}

/**
 * Wait for a tab to finish loading
 */
function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (id, changeInfo) => {
      if (id === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    
    // Also check if already loaded
    chrome.tabs.get(tabId, (tab) => {
      if (tab.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    });
    
    // Timeout after 30 seconds
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 30000);
  });
}

/**
 * Sleep helper
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Stop current shopping task
 */
async function stopShopping() {
  const data = await chrome.storage.local.get(['currentTask']);
  const task = data.currentTask;
  
  if (task) {
    task.status = 'stopped';
    task.stoppedAt = new Date().toISOString();
    
    // Save to history
    const historyData = await chrome.storage.local.get(['taskHistory']);
    const history = historyData.taskHistory || [];
    history.unshift(task);
    
    await chrome.storage.local.set({ 
      currentTask: null,
      taskHistory: history.slice(0, 50)
    });
  }
  
  return { success: true };
}

/**
 * Get current task status
 */
async function getTaskStatus() {
  const data = await chrome.storage.local.get(['currentTask']);
  return { task: data.currentTask };
}

/**
 * Handle item added by content script
 */
async function handleItemAdded(data) {
  const { itemName, productName, price } = data;
  console.log('[Sally] Item added:', itemName, '->', productName, '£' + price);
  
  const storage = await chrome.storage.local.get(['currentTask']);
  const task = storage.currentTask;
  
  if (task) {
    task.itemsAdded = (task.itemsAdded || 0) + 1;
    
    // Update the specific item in the task
    const item = task.items.find(i => i.name === itemName && i.status === 'pending');
    if (item) {
      item.status = 'added';
      item.productName = productName;
      item.price = price;
    }
    
    await chrome.storage.local.set({ currentTask: task });
    
    // Notify popup
    chrome.runtime.sendMessage({ type: 'TASK_UPDATED', task }).catch(() => {});
  }
  
  return { success: true };
}

/**
 * Handle item failed by content script
 */
async function handleItemFailed(data) {
  const { itemName, reason } = data;
  console.log('[Sally] Item failed:', itemName, '-', reason);
  
  const storage = await chrome.storage.local.get(['currentTask']);
  const task = storage.currentTask;
  
  if (task) {
    task.itemsFailed = (task.itemsFailed || 0) + 1;
    
    // Update the specific item in the task
    const item = task.items.find(i => i.name === itemName && i.status === 'pending');
    if (item) {
      item.status = 'failed';
      item.failReason = reason;
    }
    
    await chrome.storage.local.set({ currentTask: task });
    
    // Notify popup
    chrome.runtime.sendMessage({ type: 'TASK_UPDATED', task }).catch(() => {});
  }
  
  return { success: true };
}

/**
 * Handle shopping complete from content script
 */
async function handleShoppingComplete() {
  console.log('[Sally] Shopping complete!');
  
  const storage = await chrome.storage.local.get(['currentTask', 'sallyStats']);
  const task = storage.currentTask;
  
  if (task) {
    task.status = 'complete';
    task.completedAt = new Date().toISOString();
    
    // Update lifetime stats
    const stats = storage.sallyStats || { totalItems: 0, totalSessions: 0, totalSpent: 0 };
    const itemsAdded = task.itemsAdded || task.items?.filter(i => i.status === 'added').length || 0;
    
    if (itemsAdded > 0 && !task.statsUpdated) {
      stats.totalItems += itemsAdded;
      stats.totalSessions += 1;
      
      // Calculate total spent from item prices
      const spent = task.items?.reduce((sum, item) => {
        return sum + (item.status === 'added' && item.price ? item.price : 0);
      }, 0) || 0;
      stats.totalSpent += spent;
      
      task.statsUpdated = true;
    }
    
    await chrome.storage.local.set({ currentTask: task, sallyStats: stats });
    
    // Save to history
    const historyData = await chrome.storage.local.get(['taskHistory']);
    const history = historyData.taskHistory || [];
    history.unshift(task);
    await chrome.storage.local.set({ taskHistory: history.slice(0, 50) });
    
    // Notify popup
    chrome.runtime.sendMessage({ type: 'SHOPPING_COMPLETE', task }).catch(() => {});
    
    // Show notification with time saved estimate
    const timeSaved = Math.round(itemsAdded * 0.5); // ~30 sec per item
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Shopping Complete! 🛒',
      message: `Added ${itemsAdded} items to your ${task.store} cart. Saved ~${timeSaved} min!`
    });
  }
  
  return { success: true };
}
