/**
 * Sally by HeySalad® - Base Content Script
 * 
 * This runs on every supermarket page and handles:
 * - Receiving shopping tasks from the background script
 * - Searching for products and adding to cart
 * - Reporting progress back to the popup
 */

(function() {
  'use strict';
  
  // Prevent double initialization
  if (window.__heysaladInitialized) return;
  window.__heysaladInitialized = true;
  
  console.log('[Sally] Content script loaded on:', window.location.hostname);
  
  // State
  let currentTask = null;
  let isProcessing = false;
  let overlayElement = null;
  
  // Shopping Agent API URL for AI matching
  const SHOPPING_AGENT_URL = 'https://shopping-agent.heysalad-o.workers.dev';
  
  /**
   * Call Shopping Agent API to match product using AI
   * @param {string} query - The item name to search for
   * @param {Array} products - List of products with name, price, index
   * @returns {Promise<{success: boolean, bestIndex: number, confidence: number, reason: string}>}
   */
  async function matchProductWithAI(query, products) {
    try {
      console.log('[Sally] Calling AI to match:', query, 'against', products.length, 'products');
      
      const response = await fetch(`${SHOPPING_AGENT_URL}/api/match-product`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          products: products.map((p, i) => ({
            name: p.name,
            price: p.price,
            inStock: p.inStock !== false,
            index: i
          }))
        })
      });
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const result = await response.json();
      console.log('[Sally] AI match result:', result);
      return result;
    } catch (error) {
      console.error('[Sally] AI matching error:', error);
      return { success: false, bestIndex: 0, confidence: 0, reason: 'API error' };
    }
  }
  
  // Listen for messages from background
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    console.log('[Sally] Message received:', message.type);
    
    if (message.type === 'START_SHOPPING_TASK') {
      currentTask = message.task;
      // Save to storage so we can resume after navigation
      chrome.storage.local.set({ currentTask });
      // Check if we need to process items or if we're on a search results page
      checkAndProcess();
      sendResponse({ success: true });
    } else if (message.type === 'STOP_SHOPPING_TASK') {
      currentTask = null;
      isProcessing = false;
      chrome.storage.local.set({ currentTask: null });
      sendResponse({ success: true });
    } else if (message.type === 'PING') {
      sendResponse({ success: true, ready: true });
    }
    
    return true;
  });
  
  // Check stored task on page load (for when we navigate to search results)
  chrome.storage.local.get(['currentTask', 'lastNavigationTime'], (data) => {
    if (data.currentTask && data.currentTask.status !== 'complete' && data.currentTask.status !== 'stopped' && data.currentTask.status !== 'checkout') {
      currentTask = data.currentTask;
      console.log('[Sally] Resuming task from storage, items:', currentTask.items.map(i => `${i.name}:${i.status}`).join(', '));
      
      // Check if we just navigated (within last 10 seconds for slow sites like Ocado)
      const now = Date.now();
      const lastNav = data.lastNavigationTime || 0;
      const host = window.location.hostname;
      const navTimeout = host.includes('ocado.com') ? 15000 : 10000; // Ocado is slow
      const justNavigated = (now - lastNav) < navTimeout;
      
      // Also check if we're on a search page
      const currentUrl = window.location.href;
      const isOnSearchPage = currentUrl.includes('/search') || 
                             currentUrl.includes('query=') || 
                             currentUrl.includes('entry=') || 
                             currentUrl.includes('searchTerm=') ||
                             currentUrl.includes('/SearchResults/');
      
      console.log('[Sally] Time since last navigation:', now - lastNav, 'ms, justNavigated:', justNavigated, 'isOnSearchPage:', isOnSearchPage);
      
      // If we're on a search page and just navigated, keep the 'searching' status
      // Otherwise reset to pending
      if (!justNavigated && !isOnSearchPage) {
        currentTask.items.forEach(item => {
          if (item.status === 'searching') {
            console.log('[Sally] Resetting item to pending:', item.name);
            item.status = 'pending';
          }
        });
      } else if (isOnSearchPage) {
        console.log('[Sally] On search page, keeping searching status');
      } else {
        console.log('[Sally] Just navigated, keeping searching status');
      }
      
      // Small delay to let page render (longer for Ocado and Tesco which are slow)
      let delay = 2000;
      if (host.includes('ocado.com')) delay = 4000;
      if (host.includes('tesco.com')) delay = 3500; // Tesco's React app needs time
      
      console.log('[Sally] Waiting', delay, 'ms for page to render on', host);
      
      setTimeout(() => {
        checkAndProcess();
      }, delay);
    }
  });
  
  /**
   * Check current page and process accordingly
   */
  async function checkAndProcess() {
    if (!currentTask || isProcessing) return;
    
    // Show overlay when we have a task
    showOverlay();
    
    const currentUrl = window.location.href;
    console.log('[Sally] Checking page:', currentUrl);
    
    // First check if there's an item already being searched
    const searchingItem = currentTask.items.find(i => i.status === 'searching');
    
    // Find the next pending item
    const pendingItem = currentTask.items.find(i => i.status === 'pending');
    
    // If we have a searching item and we're on a search page, process it
    if (searchingItem && isSearchResultsPage(currentUrl)) {
      console.log('[Sally] Found searching item on search page:', searchingItem.name);
      isProcessing = true;
      await processSearchResults(searchingItem);
      isProcessing = false;
      return;
    }
    
    if (!pendingItem && !searchingItem) {
      console.log('[Sally] No pending items, shopping complete');
      showToast('Shopping complete! 🎉', 'success');
      chrome.runtime.sendMessage({ type: 'SHOPPING_COMPLETE' });
      setTimeout(hideOverlay, 3000);
      return;
    }
    
    // Use searching item if exists, otherwise pending
    const itemToProcess = searchingItem || pendingItem;
    
    // Mark item as searching if not already
    if (itemToProcess.status !== 'searching') {
      itemToProcess.status = 'searching';
      chrome.storage.local.set({ currentTask });
    }
    updateOverlay();
    
    // Check if we're on a search results page
    if (isSearchResultsPage(currentUrl)) {
      console.log('[Sally] On search results page, looking for products...');
      isProcessing = true;
      await processSearchResults(itemToProcess);
      isProcessing = false;
    } else if (isHomePage()) {
      // Navigate to search
      console.log('[Sally] Not on search page, searching for:', itemToProcess.name);
      navigateToSearch(itemToProcess.name);
    }
  }
  
  /**
   * Check if current URL is a search results page
   */
  function isSearchResultsPage(url) {
    // ASDA: /search/query
    // Tesco: /groceries/en-GB/search?query=
    // Sainsbury's: /SearchResults/query
    // Ocado: /search?q=
    // Waitrose: /search?searchTerm=
    const isSearch = url.includes('/search') || 
           url.includes('query=') || 
           url.includes('searchTerm=') ||
           url.includes('/SearchResults/') ||
           url.includes('?q=') ||
           url.includes('&q=');
    
    console.log('[Sally] isSearchResultsPage check:', url, '->', isSearch);
    return isSearch;
  }
  
  /**
   * Check if current URL is the store home page or any non-search page
   */
  function isHomePage() {
    // If not a search page, treat as home page (need to navigate to search)
    return !isSearchResultsPage(window.location.href);
  }
  
  /**
   * Navigate to search results for an item
   */
  function navigateToSearch(query) {
    const host = window.location.hostname;
    const currentUrl = window.location.href;
    let searchUrl;
    
    if (host.includes('tesco.com')) {
      searchUrl = `https://www.tesco.com/groceries/en-GB/search?query=${encodeURIComponent(query)}`;
    } else if (host.includes('sainsburys.co.uk')) {
      searchUrl = `https://www.sainsburys.co.uk/gol-ui/SearchResults/${encodeURIComponent(query)}`;
    } else if (host.includes('asda.com')) {
      searchUrl = `https://groceries.asda.com/search/${encodeURIComponent(query)}`;
    } else if (host.includes('ocado.com')) {
      searchUrl = `https://www.ocado.com/search?q=${encodeURIComponent(query)}`;
    } else if (host.includes('waitrose.com')) {
      searchUrl = `https://www.waitrose.com/ecom/shop/search?searchTerm=${encodeURIComponent(query)}`;
    }
    
    if (searchUrl) {
      // Check if we're already on a search page (prevent refresh loop)
      const isOnSearchPage = currentUrl.includes('/search') || 
                             currentUrl.includes('query=') || 
                             currentUrl.includes('?q=') || 
                             currentUrl.includes('&q=') ||
                             currentUrl.includes('searchTerm=') ||
                             currentUrl.includes('/SearchResults/');
      
      if (isOnSearchPage) {
        // Extract current search term from URL
        let currentSearchTerm = '';
        try {
          const urlObj = new URL(currentUrl);
          currentSearchTerm = urlObj.searchParams.get('query') || 
                              urlObj.searchParams.get('q') ||  // Ocado uses ?q=
                              urlObj.searchParams.get('searchTerm') || 
                              currentUrl.split('/SearchResults/')[1]?.split('?')[0] ||
                              currentUrl.split('/search/')[1]?.split('?')[0] || '';
          currentSearchTerm = decodeURIComponent(currentSearchTerm).toLowerCase();
        } catch (e) {
          console.log('[Sally] Error parsing URL:', e);
        }
        
        const targetSearch = query.toLowerCase();
        
        // If we're already searching for something similar, don't navigate again
        if (currentSearchTerm && (
            currentSearchTerm.includes(targetSearch.substring(0, 4)) ||
            targetSearch.includes(currentSearchTerm.substring(0, 4))
        )) {
          console.log('[Sally] Already on search page for:', query, '(current:', currentSearchTerm, ') - processing results instead');
          // Process results directly instead of navigating
          setTimeout(() => checkAndProcess(), 1000);
          return;
        }
      }
      
      console.log('[Sally] Navigating to:', searchUrl);
      // Save navigation timestamp to prevent re-navigation after page reload
      chrome.storage.local.set({ lastNavigationTime: Date.now() }, () => {
        window.location.href = searchUrl;
      });
    }
  }
  
  /**
   * Process search results - find product and add to cart
   */
  async function processSearchResults(item) {
    console.log('[Sally] Processing search results for:', item.name);
    console.log('[Sally] Current URL:', window.location.href);
    
    // Wait for page to fully load
    await waitForPageLoad();
    console.log('[Sally] Page loaded');
    
    // Accept cookies if present
    await acceptCookies();
    
    // Wait for products to load (dynamic content) - ASDA and Tesco can be slow
    let products = [];
    let attempts = 0;
    const host = window.location.hostname;
    const maxAttempts = host.includes('tesco.com') ? 20 : 15; // Tesco needs more time
    const waitTime = host.includes('tesco.com') ? 1500 : 1000; // Longer wait for Tesco
    
    console.log('[Sally] Waiting for products on', host, '- max attempts:', maxAttempts);
    
    while (products.length === 0 && attempts < maxAttempts) {
      await sleep(waitTime);
      products = findProducts();
      console.log('[Sally] Attempt', attempts + 1, '- Found', products.length, 'products');
      
      // Log what we can see on the page for debugging
      if (attempts === 5 && products.length === 0) {
        console.log('[Sally] Debug - Page HTML sample:', document.body.innerHTML.substring(0, 2000));
        console.log('[Sally] Debug - All buttons:', document.querySelectorAll('button').length);
        console.log('[Sally] Debug - All links:', document.querySelectorAll('a').length);
        
        // Tesco-specific debugging
        if (window.location.hostname.includes('tesco.com')) {
          console.log('[Sally] Tesco Debug - Looking for product elements...');
          console.log('[Sally] Tesco Debug - [data-auto] elements:', document.querySelectorAll('[data-auto]').length);
          console.log('[Sally] Tesco Debug - li elements:', document.querySelectorAll('li').length);
          console.log('[Sally] Tesco Debug - ul elements:', document.querySelectorAll('ul').length);
          // Log first few data-auto values
          const dataAutos = document.querySelectorAll('[data-auto]');
          dataAutos.forEach((el, i) => {
            if (i < 10) console.log(`[Sally] Tesco Debug - data-auto[${i}]:`, el.getAttribute('data-auto'), el.tagName);
          });
        }
      }
      
      attempts++;
    }
    
    if (products.length === 0) {
      console.log('[Sally] No products found after', maxAttempts, 'attempts');
      
      // Try one more thing - look for any product-like elements
      const fallbackProducts = document.querySelectorAll('[class*="product"], [class*="Product"], [data-auto-id*="product"]');
      console.log('[Sally] Fallback product search found:', fallbackProducts.length, 'elements');
      
      // Tesco-specific fallback: look for list items with add buttons
      if (fallbackProducts.length === 0 && window.location.hostname.includes('tesco.com')) {
        console.log('[Sally] Trying Tesco-specific fallback...');
        // Find all list items that contain an add button
        const allLis = document.querySelectorAll('li');
        const tescoProducts = Array.from(allLis).filter(li => {
          const hasAddBtn = li.querySelector('button[class*="add"], button[aria-label*="Add"], button[aria-label*="trolley"]');
          const hasPrice = li.querySelector('[class*="price"], [class*="Price"]');
          return hasAddBtn || hasPrice;
        });
        console.log('[Sally] Tesco fallback found:', tescoProducts.length, 'potential products');
        if (tescoProducts.length > 0) {
          products = tescoProducts;
        }
      }
      
      if (fallbackProducts.length > 0 && products.length === 0) {
        products = Array.from(fallbackProducts);
      }
      
      if (products.length === 0) {
        reportItemFailed(item, 'No products found');
        await sleep(1000);
        moveToNextItem();
        return;
      }
    }
    
    // Extract info from all products for AI matching
    const productInfoList = products.slice(0, 10).map((p, i) => {
      const info = extractProductInfo(p);
      return { ...info, index: i, inStock: true };
    });
    
    console.log('[Sally] Found', productInfoList.length, 'products to match against');
    
    // Use AI to find the best matching product
    let bestIndex = 0;
    let aiUsed = false;
    try {
      showToast('🤖 AI selecting best match...', 'info');
      const matchResult = await matchProductWithAI(item.name, productInfoList);
      if (matchResult.success && matchResult.bestIndex !== undefined) {
        bestIndex = matchResult.bestIndex;
        aiUsed = true;
        console.log('[Sally] AI matched product:', matchResult.reason, '(confidence:', matchResult.confidence, ')');
        if (matchResult.confidence >= 0.7) {
          showToast(`✨ AI found: ${productInfoList[bestIndex]?.name?.substring(0, 30)}...`, 'success');
        } else {
          showToast(`🤔 Best guess: ${productInfoList[bestIndex]?.name?.substring(0, 30)}...`, 'info');
        }
      }
    } catch (e) {
      console.log('[Sally] AI matching failed, using first product:', e);
      showToast('Using first result (AI unavailable)', 'info');
    }
    
    // Get the best matching product
    const product = products[bestIndex];
    console.log('[Sally] Selected product index:', bestIndex, product.tagName, product.className);
    
    const productInfo = extractProductInfo(product);
    console.log('[Sally] Selected product:', productInfo);
    
    // Scroll product into view
    product.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await sleep(800);
    
    // Try to add to cart
    let addButton = findAddButton(product);
    
    if (!addButton) {
      console.log('[Sally] Add button not found in product, trying page-level search...');
      // Try finding any Add button on the page near this product
      addButton = findAddButtonOnPage();
    }
    
    if (!addButton) {
      console.log('[Sally] No add button found anywhere');
      // Log all buttons for debugging
      const allButtons = document.querySelectorAll('button');
      console.log('[Sally] All buttons on page:', allButtons.length);
      allButtons.forEach((btn, i) => {
        if (i < 10) { // Log first 10
          console.log(`[Sally] Button ${i}:`, btn.textContent?.trim().substring(0, 30), btn.className.substring(0, 50));
        }
      });
      
      reportItemFailed(item, 'Add button not found');
      await sleep(1000);
      moveToNextItem();
      return;
    }
    
    // Click add button for each quantity
    for (let i = 0; i < item.quantity; i++) {
      console.log('[Sally] Clicking add button, qty:', i + 1, 'button:', addButton.tagName, addButton.className?.substring(0, 50));
      addButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(600);
      
      // Try multiple click methods for React/Next.js sites like Tesco
      let clicked = false;
      
      // Method 1: Focus and click (works best for React)
      try {
        addButton.focus();
        await sleep(100);
        addButton.click();
        clicked = true;
        console.log('[Sally] Click method 1 (focus+click) succeeded');
      } catch (e) {
        console.log('[Sally] Click method 1 failed:', e.message);
      }
      
      // Method 2: MouseEvent with all properties (for stubborn buttons)
      if (!clicked) {
        try {
          const rect = addButton.getBoundingClientRect();
          const mouseDown = new MouseEvent('mousedown', {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: rect.left + rect.width / 2,
            clientY: rect.top + rect.height / 2
          });
          const mouseUp = new MouseEvent('mouseup', {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: rect.left + rect.width / 2,
            clientY: rect.top + rect.height / 2
          });
          const click = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: rect.left + rect.width / 2,
            clientY: rect.top + rect.height / 2
          });
          
          addButton.dispatchEvent(mouseDown);
          await sleep(50);
          addButton.dispatchEvent(mouseUp);
          await sleep(50);
          addButton.dispatchEvent(click);
          clicked = true;
          console.log('[Sally] Click method 2 (full mouse events) succeeded');
        } catch (e) {
          console.log('[Sally] Click method 2 failed:', e.message);
        }
      }
      
      // Method 3: Pointer events (for touch-enabled sites)
      if (!clicked) {
        try {
          const pointerDown = new PointerEvent('pointerdown', { bubbles: true, cancelable: true });
          const pointerUp = new PointerEvent('pointerup', { bubbles: true, cancelable: true });
          addButton.dispatchEvent(pointerDown);
          await sleep(50);
          addButton.dispatchEvent(pointerUp);
          console.log('[Sally] Click method 3 (pointer events) attempted');
        } catch (e) {
          console.log('[Sally] Click method 3 failed:', e.message);
        }
      }
      
      await sleep(2000); // Wait longer for cart to update (Tesco is slow)
    }
    
    // Report success
    reportItemAdded(item, productInfo.name, productInfo.price * item.quantity);
    
    // Move to next item
    await sleep(2000);
    moveToNextItem();
  }
  
  /**
   * Find product cards on the page
   */
  function findProducts() {
    const host = window.location.hostname;
    let selectors = [];
    
    // Use store-specific selectors first
    if (host.includes('asda.com')) {
      selectors = [
        // ASDA 2024 selectors
        '[data-auto-id="productTile"]',
        '.co-product',
        '.co-item',
        '[class*="co-product"]',
        '[class*="ProductTile"]',
        '[class*="product-tile"]',
        '.search-page-content__products-wrapper li',
        'li[data-auto-id]',
        // ASDA grid items
        '[class*="search-page"] li',
        '[class*="SearchResults"] li',
        // Generic product containers
        'article[class*="product"]',
        'div[class*="product-card"]'
      ];
    } else if (host.includes('tesco.com')) {
      selectors = [
        // Tesco 2024/2025 selectors
        '[data-auto="product-tile"]',
        'li[class*="product-list"]',
        '.product-tile',
        '.product-list--list-item',
        '[class*="product-tile"]',
        '[class*="ProductTile"]',
        // Tesco search results grid
        'ul[class*="product-list"] > li',
        '[class*="styled__ProductTileWrapper"]',
        '[class*="StyledProductTile"]',
        // Generic product containers
        'article[class*="product"]',
        '[data-testid*="product"]',
        'li[data-auto]'
      ];
    } else if (host.includes('sainsburys.co.uk')) {
      selectors = [
        '[data-test-id="product-tile"]',
        '.pt-grid-item',
        '.ln-c-card',
        '[class*="product-tile"]'
      ];
    } else if (host.includes('ocado.com')) {
      selectors = [
        // Ocado 2024 selectors
        '[data-sku]',
        '.fop-item',
        '[class*="fop-"]',
        '.product-tile',
        '[class*="ProductTile"]',
        '[class*="product-pod"]',
        // Ocado search results
        '[class*="search-results"] li',
        '[class*="SearchResults"] li',
        // Generic
        '[class*="product"]',
        'article'
      ];
    } else if (host.includes('waitrose.com')) {
      selectors = [
        '[data-testid="product-pod"]',
        '.productPod',
        '[class*="product"]'
      ];
    }
    
    // Add generic fallbacks
    selectors.push(
      '[class*="product-card"]',
      '[class*="ProductCard"]',
      'article[class*="product"]',
      '[role="listitem"]'
    );
    
    for (const selector of selectors) {
      try {
        const products = document.querySelectorAll(selector);
        if (products.length > 0) {
          console.log('[Sally] Found', products.length, 'products with selector:', selector);
          return Array.from(products);
        }
      } catch (e) {
        // Invalid selector, skip
      }
    }
    
    return [];
  }
  
  /**
   * Extract product info from a product card
   */
  function extractProductInfo(product) {
    // Title selectors (order matters - more specific first)
    const titleSelectors = [
      // ASDA
      '[data-auto-id="productTitle"]',
      '.co-product__title',
      '[class*="ProductTitle"]',
      '[class*="product-title"]',
      // Tesco 2024/2025
      '[data-auto="product-tile--title"]',
      '.product-tile--title',
      '[class*="styled__Title"]',
      '[class*="StyledTitle"]',
      '[class*="ProductTitle"]',
      'a[class*="product-tile"] span',
      'h3[class*="styled"]',
      // Sainsbury's
      '[data-test-id="product-tile-title"]',
      '.pt__title',
      '.ln-c-card__title',
      // Ocado
      '.fop-title',
      '[class*="fop-title"]',
      '[class*="product-name"]',
      '[class*="ProductName"]',
      // Waitrose
      '[data-testid="product-pod-title"]',
      // Generic fallbacks
      'h2', 'h3', 
      'a[href*="product"]',
      'a'
    ];
    
    // Price selectors
    const priceSelectors = [
      // ASDA
      '[data-auto-id="productPrice"]',
      '.co-product__price',
      '[class*="ProductPrice"]',
      '[class*="price-per-sellable"]',
      // Tesco 2024/2025
      '[data-auto="price-value"]',
      '.price-per-sellable-unit .value',
      '[class*="styled__Price"]',
      '[class*="StyledPrice"]',
      '[class*="ProductPrice"]',
      'span[class*="price"]',
      // Sainsbury's
      '[data-test-id="pt-retail-price"]',
      '.pt__cost__retail-price',
      // Ocado
      '.fop-price',
      '[class*="fop-price"]',
      '[class*="product-price"]',
      '[class*="ProductPrice"]',
      // Waitrose
      '[data-testid="product-pod-price"]',
      // Generic
      '.price',
      '[class*="price"]'
    ];
    
    let name = 'Unknown Product';
    let price = 0;
    
    for (const selector of titleSelectors) {
      try {
        const el = product.querySelector(selector);
        if (el && el.textContent.trim()) {
          name = el.textContent.trim().substring(0, 100); // Limit length
          console.log('[Sally] Found product name:', name.substring(0, 50));
          break;
        }
      } catch (e) {}
    }
    
    for (const selector of priceSelectors) {
      try {
        const el = product.querySelector(selector);
        if (el) {
          const match = el.textContent.match(/£?([\d.]+)/);
          if (match) {
            price = parseFloat(match[1]);
            console.log('[Sally] Found price: £' + price);
            break;
          }
        }
      } catch (e) {}
    }
    
    return { name, price };
  }
  
  /**
   * Find the add to cart button within a product card
   */
  function findAddButton(product) {
    const host = window.location.hostname;
    let selectors = [];
    
    // Store-specific selectors first
    if (host.includes('asda.com')) {
      selectors = [
        // ASDA 2024 selectors
        '[data-auto-id="addButton"]',
        '[data-auto-id="btnAdd"]',
        '.co-product__add-to-trolley',
        'button[class*="add-to-trolley"]',
        'button[class*="AddToTrolley"]',
        'button[class*="add-button"]',
        'button[class*="AddButton"]',
        '[class*="quantity-controls"] button',
        // ASDA uses + button sometimes
        'button[aria-label*="Add"]',
        'button[aria-label*="add"]',
        'button[aria-label*="trolley"]',
        'button[aria-label*="basket"]'
      ];
    } else if (host.includes('tesco.com')) {
      selectors = [
        // Tesco 2024/2025 add button selectors - most specific first
        'button[data-auto="add-button"]',
        '[data-auto="add-button"]',
        // Tesco quantity/add controls
        'button[class*="add-control"]',
        '[class*="add-control"] button',
        '.add-control button',
        '.add-control',
        // Tesco trolley buttons
        '.product-add-to-trolley',
        'button[class*="trolley"]',
        '[class*="trolley"] button',
        // Styled components (Tesco uses these)
        'button[class*="AddButton"]',
        'button[class*="add-to-basket"]',
        'button[class*="AddToBasket"]',
        'button[class*="styled__AddButton"]',
        'button[class*="StyledAddButton"]',
        'button[class*="Styled"] [class*="Add"]',
        // Tesco quantity increment (sometimes the add is a + button)
        'button[class*="quantity"]',
        'button[class*="increment"]',
        'button[class*="plus"]',
        // Aria labels
        'button[aria-label*="Add"]',
        'button[aria-label*="add"]',
        'button[aria-label*="trolley"]',
        'button[aria-label*="basket"]',
        'button[aria-label*="Trolley"]',
        'button[aria-label*="Basket"]',
        // Generic with add in class
        'button[class*="add"]',
        'button[class*="Add"]'
      ];
    } else if (host.includes('sainsburys.co.uk')) {
      selectors = [
        '[data-test-id="add-button"]',
        '.pt__icons__add',
        '.ln-c-button--filled',
        'button[class*="add"]'
      ];
    } else if (host.includes('ocado.com')) {
      selectors = [
        // Ocado 2024 selectors
        '.fop-add-to-basket',
        '[class*="add-to-basket"]',
        '[class*="AddToBasket"]',
        'button[class*="quantity"]',
        '[data-sku] button',
        'button[aria-label*="Add"]',
        'button[aria-label*="basket"]',
        'button[class*="add"]',
        // Ocado uses + buttons
        'button[class*="increment"]',
        'button[class*="plus"]'
      ];
    } else if (host.includes('waitrose.com')) {
      selectors = [
        '[data-testid="add-to-trolley-button"]',
        '.addToTrolley',
        'button[class*="add"]'
      ];
    }
    
    // Generic fallbacks
    selectors.push(
      'button[class*="add"]',
      'button[aria-label*="Add"]',
      'button[aria-label*="add"]'
    );
    
    for (const selector of selectors) {
      try {
        const btn = product.querySelector(selector);
        if (btn && !btn.disabled) {
          console.log('[Sally] Found add button with selector:', selector);
          return btn;
        }
      } catch (e) {
        // Invalid selector, skip
      }
    }
    
    // Try finding any button in the product card with "add" text
    const buttons = product.querySelectorAll('button');
    console.log('[Sally] Searching', buttons.length, 'buttons in product card for add text...');
    
    for (const btn of buttons) {
      const text = (btn.textContent || '').toLowerCase().trim();
      const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase();
      const title = (btn.getAttribute('title') || '').toLowerCase();
      
      // Log button details for debugging
      if (window.location.hostname.includes('tesco.com')) {
        console.log('[Sally] Tesco button:', text.substring(0, 20), '| aria:', ariaLabel.substring(0, 20), '| class:', btn.className?.substring(0, 30));
      }
      
      // Look for add-related text - expanded patterns for Tesco
      if (!btn.disabled && btn.offsetParent !== null) { // visible and enabled
        if (text === 'add' || 
            text === '+' ||
            text.includes('add to') || 
            text.includes('add item') ||
            text.includes('add to trolley') ||
            text.includes('add to basket') ||
            ariaLabel.includes('add') ||
            ariaLabel.includes('trolley') ||
            ariaLabel.includes('basket') ||
            title.includes('add') ||
            title.includes('trolley')) {
          console.log('[Sally] Found add button by text:', text || ariaLabel || title);
          return btn;
        }
      }
    }
    
    // Last resort: look for any clickable element with + icon or add text
    const clickables = product.querySelectorAll('button, [role="button"], a[class*="add"]');
    for (const el of clickables) {
      const text = (el.textContent || '').trim();
      if (text === '+' || text === 'Add') {
        console.log('[Sally] Found add button by + or Add text');
        return el;
      }
    }
    
    // Tesco-specific: look for the first button that's not a link/navigation
    if (window.location.hostname.includes('tesco.com')) {
      console.log('[Sally] Tesco fallback: looking for any actionable button...');
      const allBtns = product.querySelectorAll('button');
      for (const btn of allBtns) {
        // Skip buttons that look like navigation or info buttons
        const text = (btn.textContent || '').toLowerCase();
        const isNavButton = text.includes('view') || text.includes('details') || text.includes('more');
        
        if (!btn.disabled && btn.offsetParent !== null && !isNavButton) {
          const rect = btn.getBoundingClientRect();
          // Button should be reasonably sized (not tiny icons)
          if (rect.width > 30 && rect.height > 20) {
            console.log('[Sally] Tesco fallback: using button with text:', btn.textContent?.trim().substring(0, 30));
            return btn;
          }
        }
      }
    }
    
    return null;
  }
  
  /**
   * Find any Add button on the page (fallback)
   * Looks for the first visible Add button, prioritizing ones near the top of the viewport
   */
  function findAddButtonOnPage() {
    const buttons = document.querySelectorAll('button, [role="button"]');
    const candidates = [];
    
    for (const btn of buttons) {
      const text = (btn.textContent || '').toLowerCase().trim();
      const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase();
      
      // Check if it's an add-related button
      const isAddButton = text === 'add' || 
                          text === '+' ||
                          text.includes('add to') || 
                          text.includes('add item') ||
                          ariaLabel.includes('add') ||
                          ariaLabel.includes('trolley') ||
                          ariaLabel.includes('basket');
      
      // Check if visible and enabled
      if (isAddButton && !btn.disabled && btn.offsetParent !== null) {
        const rect = btn.getBoundingClientRect();
        // Only consider buttons in the viewport
        if (rect.top >= 0 && rect.top < window.innerHeight && rect.width > 0 && rect.height > 0) {
          candidates.push({ btn, top: rect.top });
        }
      }
    }
    
    // Sort by vertical position (top of page first)
    candidates.sort((a, b) => a.top - b.top);
    
    if (candidates.length > 0) {
      console.log('[Sally] Found', candidates.length, 'add buttons on page, using first one');
      return candidates[0].btn;
    }
    
    return null;
  }
  
  /**
   * Accept cookies banner if present
   */
  async function acceptCookies() {
    const selectors = [
      '#onetrust-accept-btn-handler',
      'button[data-testid="accept-cookies"]',
      '[data-action="accept"]',
      'button[class*="accept"]',
      '#accept-cookies'
    ];
    
    for (const selector of selectors) {
      const btn = document.querySelector(selector);
      if (btn) {
        console.log('[Sally] Accepting cookies');
        btn.click();
        await sleep(500);
        return;
      }
    }
  }
  
  /**
   * Report item added successfully
   */
  function reportItemAdded(item, productName, price) {
    console.log('[Sally] Item added:', item.name, '->', productName, '£' + price);
    
    // Update task
    item.status = 'added';
    item.productName = productName;
    item.price = price;
    chrome.storage.local.set({ currentTask });
    
    // Update overlay
    updateOverlay();
    showToast(`Added: ${item.name}`, 'success');
    
    // Notify background
    chrome.runtime.sendMessage({
      type: 'ITEM_ADDED',
      data: { itemName: item.name, productName, price }
    });
    
    // Update running stats (items added this session)
    chrome.storage.local.get(['sessionItemsAdded'], (data) => {
      const count = (data.sessionItemsAdded || 0) + item.quantity;
      chrome.storage.local.set({ sessionItemsAdded: count });
    });
  }
  
  /**
   * Report item failed
   */
  function reportItemFailed(item, reason) {
    console.log('[Sally] Item failed:', item.name, '-', reason);
    
    // Update task
    item.status = 'failed';
    item.failReason = reason;
    chrome.storage.local.set({ currentTask });
    
    // Update overlay
    updateOverlay();
    showToast(`Not found: ${item.name}`, 'error');
    
    // Notify background
    chrome.runtime.sendMessage({
      type: 'ITEM_FAILED',
      data: { itemName: item.name, reason }
    });
  }
  
  /**
   * Move to the next item in the list
   */
  function moveToNextItem() {
    if (!currentTask) return;
    
    const pendingItem = currentTask.items.find(i => i.status === 'pending');
    if (pendingItem) {
      console.log('[Sally] Moving to next item:', pendingItem.name);
      navigateToSearch(pendingItem.name);
    } else {
      console.log('[Sally] All items processed, going to checkout!');
      goToCheckout();
    }
  }
  
  /**
   * Navigate to the checkout/trolley page
   */
  function goToCheckout() {
    const host = window.location.hostname;
    let checkoutUrl;
    
    if (host.includes('tesco.com')) {
      checkoutUrl = 'https://www.tesco.com/groceries/en-GB/trolley';
    } else if (host.includes('sainsburys.co.uk')) {
      checkoutUrl = 'https://www.sainsburys.co.uk/gol-ui/trolley';
    } else if (host.includes('asda.com')) {
      checkoutUrl = 'https://groceries.asda.com/trolley';
    } else if (host.includes('ocado.com')) {
      checkoutUrl = 'https://www.ocado.com/webshop/getBasket.do';
    } else if (host.includes('waitrose.com')) {
      checkoutUrl = 'https://www.waitrose.com/ecom/shop/trolley';
    }
    
    if (checkoutUrl) {
      console.log('[Sally] Navigating to checkout:', checkoutUrl);
      showToast('Shopping complete! Going to checkout... 🛒', 'success');
      
      // Update task status
      currentTask.status = 'checkout';
      chrome.storage.local.set({ currentTask });
      
      // Notify background
      chrome.runtime.sendMessage({ type: 'SHOPPING_COMPLETE' });
      
      // Navigate after a short delay so user sees the toast
      setTimeout(() => {
        window.location.href = checkoutUrl;
      }, 1500);
    } else {
      chrome.runtime.sendMessage({ type: 'SHOPPING_COMPLETE' });
    }
  }
  
  /**
   * Wait for page to fully load
   */
  function waitForPageLoad() {
    return new Promise(resolve => {
      if (document.readyState === 'complete') {
        resolve();
      } else {
        window.addEventListener('load', resolve);
      }
    });
  }
  
  /**
   * Sleep helper
   */
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // SVG Icons
  const ICONS = {
    salad: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 21h10"/><path d="M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z"/><path d="M11.38 12a2.4 2.4 0 0 1-.4-4.77 2.4 2.4 0 0 1 3.2-2.77 2.4 2.4 0 0 1 3.47-.63 2.4 2.4 0 0 1 3.37 3.37 2.4 2.4 0 0 1-1.1 3.7 2.51 2.51 0 0 1 .03 1.1"/><path d="m13 12 4-4"/><path d="M10.9 7.25A3.99 3.99 0 0 0 4 10c0 .73.2 1.41.54 2"/></svg>',
    bot: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="18" height="10" x="3" y="11" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><line x1="8" x2="8" y1="16" y2="16"/><line x1="16" x2="16" y1="16" y2="16"/></svg>',
    cart: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>',
    check: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>',
    x: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    clock: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    circle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>',
    minus: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    stop: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="14" height="14" x="5" y="5" rx="2"/></svg>'
  };
  
  /**
   * Create and show the overlay UI
   */
  function showOverlay() {
    if (overlayElement) return;
    
    overlayElement = document.createElement('div');
    overlayElement.id = 'heysalad-overlay';
    overlayElement.innerHTML = `
      <div class="heysalad-header">
        <span class="heysalad-title">Sally is Shopping</span>
        <button class="heysalad-minimize" id="heysalad-minimize">${ICONS.minus}</button>
      </div>
      <div class="heysalad-body">
        <div class="heysalad-status">
          <span class="heysalad-status-icon">${ICONS.bot}</span>
          <span class="heysalad-status-text" id="heysalad-status-text">Starting...</span>
        </div>
        <div class="heysalad-progress">
          <div class="heysalad-progress-bar">
            <div class="heysalad-progress-fill" id="heysalad-progress-fill"></div>
          </div>
          <div class="heysalad-progress-text" id="heysalad-progress-text">0 of 0 items</div>
        </div>
        <div class="heysalad-items" id="heysalad-items"></div>
        <div class="heysalad-actions">
          <button class="heysalad-btn heysalad-btn-primary" id="heysalad-checkout" style="display:none;">${ICONS.cart} View Cart</button>
          <button class="heysalad-btn heysalad-btn-secondary" id="heysalad-stop">${ICONS.stop} Stop</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(overlayElement);
    
    // Make overlay draggable
    makeDraggable(overlayElement);
    
    // Event listeners
    document.getElementById('heysalad-minimize').addEventListener('click', (e) => {
      e.stopPropagation();
      overlayElement.classList.toggle('minimized');
    });
    
    document.getElementById('heysalad-stop').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'STOP_SHOPPING' });
      hideOverlay();
    });
    
    document.getElementById('heysalad-checkout').addEventListener('click', () => {
      goToCheckout();
    });
    
    updateOverlay();
  }
  
  /**
   * Make an element draggable by its header
   */
  function makeDraggable(element) {
    const header = element.querySelector('.heysalad-header');
    if (!header) return;
    
    let isDragging = false;
    let startX, startY, initialX, initialY;
    
    header.style.cursor = 'grab';
    
    header.addEventListener('mousedown', (e) => {
      // Don't drag if clicking on minimize button
      if (e.target.closest('.heysalad-minimize')) return;
      
      isDragging = true;
      header.style.cursor = 'grabbing';
      
      startX = e.clientX;
      startY = e.clientY;
      
      const rect = element.getBoundingClientRect();
      initialX = rect.left;
      initialY = rect.top;
      
      e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      
      let newX = initialX + dx;
      let newY = initialY + dy;
      
      // Keep within viewport bounds
      const maxX = window.innerWidth - element.offsetWidth;
      const maxY = window.innerHeight - element.offsetHeight;
      
      newX = Math.max(0, Math.min(newX, maxX));
      newY = Math.max(0, Math.min(newY, maxY));
      
      element.style.left = newX + 'px';
      element.style.top = newY + 'px';
      element.style.right = 'auto';
    });
    
    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        header.style.cursor = 'grab';
      }
    });
  }
  
  /**
   * Update the overlay with current task state
   */
  function updateOverlay() {
    if (!overlayElement || !currentTask) return;
    
    const statusText = document.getElementById('heysalad-status-text');
    const progressFill = document.getElementById('heysalad-progress-fill');
    const progressText = document.getElementById('heysalad-progress-text');
    const itemsContainer = document.getElementById('heysalad-items');
    
    if (!statusText) return;
    
    // Find current item being processed
    const pendingItem = currentTask.items.find(i => i.status === 'pending');
    const searchingItem = currentTask.items.find(i => i.status === 'searching');
    
    // Show/hide checkout button
    const checkoutBtn = document.getElementById('heysalad-checkout');
    const stopBtn = document.getElementById('heysalad-stop');
    
    if (searchingItem) {
      statusText.textContent = `Searching for ${searchingItem.name}...`;
      if (checkoutBtn) checkoutBtn.style.display = 'none';
      if (stopBtn) stopBtn.style.display = 'block';
    } else if (pendingItem) {
      statusText.textContent = `Next: ${pendingItem.name}`;
      if (checkoutBtn) checkoutBtn.style.display = 'none';
      if (stopBtn) stopBtn.style.display = 'block';
    } else {
      statusText.textContent = 'Shopping complete!';
      if (checkoutBtn) checkoutBtn.style.display = 'block';
      if (stopBtn) stopBtn.innerHTML = `${ICONS.x} Close`;
    }
    
    // Progress
    const total = currentTask.items.length;
    const completed = currentTask.items.filter(i => i.status === 'added' || i.status === 'failed').length;
    const percent = total > 0 ? (completed / total) * 100 : 0;
    
    progressFill.style.width = `${percent}%`;
    progressText.textContent = `${completed} of ${total} items`;
    
    // Items list with SVG icons
    itemsContainer.innerHTML = currentTask.items.map(item => {
      const statusClass = item.status || 'pending';
      const icon = item.status === 'added' ? ICONS.check : 
                   item.status === 'failed' ? ICONS.x : 
                   item.status === 'searching' ? ICONS.clock : ICONS.circle;
      const price = item.price ? `£${item.price.toFixed(2)}` : '';
      
      return `
        <div class="heysalad-item">
          <span class="heysalad-item-status ${statusClass}">${icon}</span>
          <span class="heysalad-item-name">${item.name}${item.quantity > 1 ? ` ×${item.quantity}` : ''}</span>
          <span class="heysalad-item-price">${price}</span>
        </div>
      `;
    }).join('');
  }
  
  /**
   * Hide and remove the overlay
   */
  function hideOverlay() {
    if (overlayElement) {
      overlayElement.remove();
      overlayElement = null;
    }
  }
  
  /**
   * Show a toast notification
   */
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `heysalad-toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.remove(), 3000);
  }
  
})();
